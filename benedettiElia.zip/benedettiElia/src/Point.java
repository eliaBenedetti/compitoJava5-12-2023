public class Point {
    //attributi
    private int x;
    private int y;

    //meodi
    public Point(){
        x=0;
        y=0;
    }//costruttore inizializzazione

    public Point(int x, int y){
        if((x >= 0 && x<= 1000 )&&(y >= 0 && y <= 1000)){
            this.x = x;
            this.y = y;
        }//if
    }//costruttore

    public void spostaX(int x1){
        x += x1;
    }//metodo


}
