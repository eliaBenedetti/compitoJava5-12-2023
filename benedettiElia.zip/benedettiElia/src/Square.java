public class Square {
    //attributi
    private int x;
    private int y;
    private int lato;

    //metodi
    public Square(){
        x=0;
        y=0;
        lato=1;
    }//costruttore inizializzazione
    public Square(int x, int y ,int lato){
        if((x >= 0 && x <= 1000) && (y >= 0 && y <= 1000) && (lato >= 0 && lato <= 1000)){
            this.x = x;
            this.y = y;
            this.lato = lato;
        }//if
    }//costruttore

    public void spostaQuadratoX(int x1){
        x+=x1;
    }//metodo per spostare orizzontalmente (asse delle x) il quadrato
    public void spostaQuadratoY(int y1){
        y+=y1;
    }//metodo per spostare verticalmente (asse delle y) il quadrato

    public Boolean verificaPuntDentroQuad(int x1, int y1){
        if((x1 >= x) && (y1 >= y) && (x1 <= x*2) && (y1 <= y/2)){
            return true;
        }
        else return false;
    }

}
